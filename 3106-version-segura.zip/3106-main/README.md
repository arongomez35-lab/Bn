# MIS ARCHIVOS — versión segura

Aplicación SwiftUI para iOS. La pantalla de acceso usa la clave de demostración `123`. Después muestra las secciones ANTENA y HOLO, donde el usuario puede importar, listar y eliminar archivos almacenados únicamente dentro del espacio privado de la aplicación.

Esta versión no incluye exploits, jailbreak, escape del sandbox, acceso al kernel ni funciones para modificar otras aplicaciones o el sistema. Los archivos importados se mantienen como archivos locales y no se ejecutan ni se aplican.

## Compilación

El workflow `.github/workflows/build-unsigned-ipa.yml` compila el proyecto `ThreeOneOSSix` y publica el IPA sin firma como artefacto de GitHub Actions. Para instalarlo en un dispositivo se necesita firmarlo con un método legítimo.
