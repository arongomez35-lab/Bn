import SwiftUI
import UniformTypeIdentifiers

@main
struct ThreeOneOSSixApp: App {
    var body: some Scene {
        WindowGroup { RootView() }
    }
}

private struct StoredFile: Identifiable {
    let id: UUID
    let name: String
    let category: FileCategory
    var url: URL
}

private enum FileCategory: String, CaseIterable, Identifiable {
    case antena = "ANTENA"
    case holo = "HOLO"
    var id: String { rawValue }
}

private struct RootView: View {
    @AppStorage("demoKeyAccepted") private var unlocked = false
    @State private var key = ""
    @State private var showError = false
    @State private var selectedCategory: FileCategory = .antena
    @State private var files: [StoredFile] = []
    @State private var showImporter = false
    @State private var importError: String?

    private var documents: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.025, green: 0.04, blue: 0.09), Color(red: 0.07, green: 0.12, blue: 0.22)], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
            if unlocked { filesScreen } else { loginScreen }
        }
        .preferredColorScheme(.dark)
        .onAppear(perform: reloadFiles)
        .alert("No se pudo importar", isPresented: Binding(get: { importError != nil }, set: { if !$0 { importError = nil } })) {
            Button("OK", role: .cancel) { importError = nil }
        } message: { Text(importError ?? "") }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.item], allowsMultipleSelection: true, onCompletion: handleImport)
    }

    private var loginScreen: some View {
        VStack(spacing: 22) {
            Image(systemName: "lock.shield.fill").font(.system(size: 52, weight: .semibold)).foregroundStyle(.cyan)
            Text("BIENVENIDO").font(.system(size: 29, weight: .black, design: .rounded)).tracking(2)
            Text("Introduce tu KEY para continuar").font(.subheadline).foregroundStyle(.white.opacity(0.7))
            SecureField("KEY", text: $key)
                .keyboardType(.numberPad).multilineTextAlignment(.center)
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .padding(16).background(.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(.white.opacity(0.16), lineWidth: 1))
            if showError { Text("KEY incorrecta. Inténtalo de nuevo.").font(.footnote.weight(.semibold)).foregroundStyle(.red) }
            Button(action: validateKey) {
                Text("ENTRAR").font(.system(size: 16, weight: .black, design: .rounded)).tracking(1.2)
                    .foregroundStyle(.black).frame(maxWidth: .infinity).padding(.vertical, 16)
                    .background(Color.cyan, in: RoundedRectangle(cornerRadius: 14))
            }
        }
        .padding(28).frame(maxWidth: 390)
        .background(.black.opacity(0.24), in: RoundedRectangle(cornerRadius: 26))
        .overlay(RoundedRectangle(cornerRadius: 26).stroke(.white.opacity(0.12), lineWidth: 1)).padding(24)
    }

    private var filesScreen: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("MIS ARCHIVOS").font(.system(size: 23, weight: .black, design: .rounded)).tracking(1)
                    Text("Almacenamiento local de la aplicación").font(.caption).foregroundStyle(.white.opacity(0.58))
                }
                Spacer()
                Button("CERRAR SESIÓN") { key = ""; unlocked = false }
                    .font(.system(size: 11, weight: .heavy)).foregroundStyle(.cyan)
                    .padding(.horizontal, 12).padding(.vertical, 10)
                    .background(.cyan.opacity(0.12), in: Capsule())
            }.padding(.horizontal, 20).padding(.top, 18).padding(.bottom, 22)

            HStack(spacing: 10) {
                ForEach(FileCategory.allCases) { category in
                    Button { selectedCategory = category } label: {
                        Text(category.rawValue).font(.system(size: 14, weight: .black)).tracking(1)
                            .frame(maxWidth: .infinity).padding(.vertical, 14)
                            .background(selectedCategory == category ? Color.cyan : Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 13))
                            .foregroundStyle(selectedCategory == category ? Color.black : Color.white)
                    }
                }
            }.padding(.horizontal, 20)

            HStack {
                Text(selectedCategory.rawValue).font(.headline)
                Spacer()
                Button { showImporter = true } label: {
                    Label("AÑADIR ARCHIVO", systemImage: "plus")
                        .font(.system(size: 11, weight: .bold)).foregroundStyle(.black)
                        .padding(.horizontal, 12).padding(.vertical, 10).background(Color.cyan, in: Capsule())
                }
            }.padding(.horizontal, 20).padding(.top, 25).padding(.bottom, 12)

            let visible = files.filter { $0.category == selectedCategory }
            if visible.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "folder").font(.system(size: 38)).foregroundStyle(.cyan.opacity(0.8))
                    Text("No hay archivos en esta categoría").font(.subheadline.weight(.semibold))
                    Text("Pulsa AÑADIR ARCHIVO para guardar archivos en esta sección.").font(.caption).foregroundStyle(.white.opacity(0.55)).multilineTextAlignment(.center)
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List {
                    ForEach(visible) { file in
                        HStack(spacing: 12) {
                            Image(systemName: "doc.fill").foregroundStyle(.cyan).font(.title3)
                            Text(file.name).font(.subheadline.weight(.medium)).lineLimit(2)
                            Spacer()
                            Button(role: .destructive) { remove(file) } label: { Image(systemName: "trash").foregroundStyle(.red.opacity(0.85)) }
                        }.listRowBackground(Color.white.opacity(0.06))
                    }
                }.scrollContentBackground(.hidden)
            }
            Text("Los archivos solo se guardan y administran dentro de esta app. No se aplican a otras apps ni modifican el sistema.")
                .font(.system(size: 10)).foregroundStyle(.white.opacity(0.45)).multilineTextAlignment(.center)
                .padding(.horizontal, 22).padding(.vertical, 12)
        }
    }

    private func validateKey() {
        guard key == "123" else { showError = true; return }
        showError = false
        unlocked = true
        reloadFiles()
    }

    private func folder(for category: FileCategory) -> URL {
        documents.appendingPathComponent(category.rawValue, isDirectory: true)
    }

    private func reloadFiles() {
        var found: [StoredFile] = []
        for category in FileCategory.allCases {
            let directory = folder(for: category)
            try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let urls = (try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)) ?? []
            found += urls.filter { !$0.hasDirectoryPath }.map { StoredFile(id: UUID(), name: $0.lastPathComponent, category: category, url: $0) }
        }
        files = found.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    private func handleImport(_ result: Result<[URL], Error>) {
        do {
            let urls = try result.get()
            for source in urls {
                let access = source.startAccessingSecurityScopedResource()
                defer { if access { source.stopAccessingSecurityScopedResource() } }
                let destination = folder(for: selectedCategory).appendingPathComponent(source.lastPathComponent)
                if FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.removeItem(at: destination) }
                try FileManager.default.copyItem(at: source, to: destination)
            }
            reloadFiles()
        } catch { importError = error.localizedDescription }
    }

    private func remove(_ file: StoredFile) {
        try? FileManager.default.removeItem(at: file.url)
        reloadFiles()
    }
}
